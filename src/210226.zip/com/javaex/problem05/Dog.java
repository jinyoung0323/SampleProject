package com.javaex.problem05;

public class Dog implements Soundable {
	@Override
	public String sound() {
		return "�۸�";
	}
}
