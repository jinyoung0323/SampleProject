package com.javaex.problem05;

public class Sparrow implements Soundable {
	@Override
	public String sound() {
		return "±±";
	}
}
