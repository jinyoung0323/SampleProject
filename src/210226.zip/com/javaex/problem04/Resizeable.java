package com.javaex.problem04;

public interface Resizeable {
	public void resize(double s);
}
