package SampleProject;

public abstract class Shape {

	public abstract double area();
	/*public abstract void draw() ;*/
}
