package SampleProject;

public class ArrayTest {

	public static void main(String[] args) {
		String[] strArray = {"SuperMan", "BatMan", "SpiderMan"};
//        strArray.length;
		for(int i = 0; i < strArray.length; i++) {
			System.out.print(strArray[i]);
		}
	}

}
