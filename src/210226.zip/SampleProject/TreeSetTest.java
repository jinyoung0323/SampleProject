package SampleProject;

import java.util.Arrays;
import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetTest {

	public static void main(String[] args) {
//		TreeSet<Integer> set = new TreeSet<Integer>(Arrays.asList(4, 2, 3));
//		
//		System.out.println(set);
//		System.out.println(set.first());
//		System.out.println(set.last());
//		System.out.println(set.higher(4));
//		System.out.println(set.lower(3));
//		
//		Iterator<Integer> iter = set.iterator();
//		while(iter.hasNext()) {
//			System.out.println("iter.next() : " + iter.next());
//		}
		
	}

}
