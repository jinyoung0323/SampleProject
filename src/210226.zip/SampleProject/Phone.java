package SampleProject;

public abstract class Phone {
	public abstract void call(String number);
}
