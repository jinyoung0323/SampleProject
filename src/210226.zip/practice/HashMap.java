package practice;

public class HashMap {
	public static void main(String[] args) {
	}
}
