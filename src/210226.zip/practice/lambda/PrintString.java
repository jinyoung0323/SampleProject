package practice.lambda;

public interface PrintString {
	public void showString(String str);
}
