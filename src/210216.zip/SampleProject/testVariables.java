package SampleProject;

import java.util.Scanner;

public class testVariables {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String temp1 = sc.nextLine();
		String[] sArr = temp1.split(",");
		for(int i = 0; i < sArr.length; i++) {
			System.out.println(sArr[i]);
		}
		
		
		sc.close();
	}

}
