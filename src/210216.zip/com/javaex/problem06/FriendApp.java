package com.javaex.problem06;
import java.util.Scanner;
public class FriendApp {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		Friend[] friends = new Friend[3];
		String name;
		String phoneNumber;
		String school;
		System.out.println("ģ���� 3�� ������ּ���.");
		for(int i = 0; i < friends.length; i++) {
			name = scanner.next();
			phoneNumber = scanner.next();
			school = scanner.next();
			friends[i] = new Friend(name, phoneNumber, school);
		}
		for(int i = 0; i < friends.length; i++) {
			friends[i].show();
		}
		scanner.close();
	}

}
