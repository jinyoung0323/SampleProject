package com.javaex.problem07;
public class BankApp {

	public static void main(String[] args) {
		Bank bank = new Bank();
		bank.choiceMenu();
	}

}
