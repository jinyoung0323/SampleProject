package com.javaex.problem07;

import java.util.Scanner;

public class Bank {
	private int money;

	// �޴�
	public void printMenu() {
		System.out.println("=====================================");
		System.out.println("1. �Ա� | 2. ��� | 3. �ܰ� | 4. ����");
		System.out.println("=====================================");
		System.out.print("����> ");
	}

	// ����
	public void deposit() {
		Scanner sc = new Scanner(System.in);
		int total = 0;
		System.out.print("���ݾ�> ");
		total = sc.nextInt();
		money += total;
		sc.close();
	}

	// ���
	public void withdraw() {
		Scanner sc = new Scanner(System.in);
		int total = 0;
		System.out.print("��ݾ�> ");
		total = sc.nextInt();
		if (total > money) {
			System.out.println("�ܾ��� �����մϴ�.");
		} else {
			money += total;
		}
		sc.close();
	}

	// �ܰ�
	public void balance() {
		System.out.print("�ܰ�> ");
		System.out.println(money);
	}

	// �޴� ����
	public void choiceMenu() {
		int num = 0;
		while (num != 4) {
			Scanner sc = new Scanner(System.in);
			printMenu();
			num = sc.nextInt();
			switch (num) {
			case 1:
				deposit();
//				break;
			case 2:
				withdraw();
//				break;
			case 3:
				balance();
//				break;
			case 4:
				System.out.println("���α׷� ����");
				break;
			default:
				System.out.println("�ٽ� �Է����ּ���.");
//				break;
			}

			sc.close();
			break;
		}
	}
}
