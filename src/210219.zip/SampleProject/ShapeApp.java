package SampleProject;

public class ShapeApp {

	public static void main(String[] args) {
//		Circle c = new Circle(3);
//		System.out.println("���� ���� : " + c.area());
//
//		Triangle t = new Triangle(3, 4);
//		System.out.println("�ﰢ���� ���� : " + t.area());
//		
//		Rectangle r = new Rectangle(3, 4);
//		System.out.println("�簢���� ���� : " + r.area());
	
		Shape c = new Circle(3);
		Shape r = new Rectangle(5, 6);
		Shape t = new Triangle(5, 6);
		
		System.out.println("Circle area : " + c.area());
		System.out.println("Rectangle area : " + r.area());
		System.out.println("Triangle area : " + t.area());
		
		System.out.println(c instanceof Circle);
		System.out.println(r instanceof Drawable);
		System.out.println(r instanceof Rectangle);
		System.out.println(r instanceof Shape);
	}

}
