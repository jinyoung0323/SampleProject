package SampleProject;

public class Animal {
	String name;
	
	public void setName(String name) {
		this.name = name;
	}
}
