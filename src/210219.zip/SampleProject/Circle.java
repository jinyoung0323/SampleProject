package SampleProject;

public class Circle extends Shape implements Drawable {
	private int r;
	
	public Circle() {}
	public Circle(int r) {
		this.r = r;
	}
	
	public double getR() {
		return r;
	}
	public void setR(int r) {
		this.r = r;
	}
	@Override
	public double area() {
		double circleArea = this.r * this.r * Math.PI;
		return circleArea;
	}
	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("�������� " + this.getR() +"�� ���� �׷Ƚ��ϴ�.");
	}
	
}
