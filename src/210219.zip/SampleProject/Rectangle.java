package SampleProject;

public class Rectangle extends Shape implements Drawable {
	private int width;
	private int height;
	
	public Rectangle() {}
	public Rectangle(int width, int height) {
		this.width = width;
		this.height = height;
	}
	
	public double getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	@Override
	public double area() {
		double RectangleArea = this.width * this.height;
		return RectangleArea;
	}
	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("�غ� " + this.getWidth() + ", ���� " + this.getHeight() +"�� �簢���� �׷Ƚ��ϴ�.");
	}
}
