package practice;
import java.util.*;
public class ArrayListPractice {

	public static void main(String[] args) {
		ArrayList<String> fruits = new ArrayList<String>();
		
		fruits.add("apple");
		System.out.println(fruits.toString());
		fruits.add("banana");
		System.out.println(fruits.toString());
		fruits.add("kiwi");
		System.out.println(fruits.toString());
	}

}
