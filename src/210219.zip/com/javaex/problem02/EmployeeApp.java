package com.javaex.problem02;

public class EmployeeApp {

	public static void main(String[] args) {
		Employee pt = new Depart("ȫ�浿", 5000, "���ߺ�");
		pt.getInformation();
	}

}
