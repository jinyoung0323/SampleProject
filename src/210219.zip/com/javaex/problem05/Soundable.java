package com.javaex.problem05;

public interface Soundable {
	public String sound();
}
