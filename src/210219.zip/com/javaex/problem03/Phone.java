package com.javaex.problem03;

public class Phone {
	public void execute(String str) {
		call();
	}
	private void call() {
		System.out.println("��ȭ��ɽ���");
	}
}
