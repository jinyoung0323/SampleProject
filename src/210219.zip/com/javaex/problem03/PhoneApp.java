package com.javaex.problem03;

public class PhoneApp {

	public static void main(String[] args) {
		Phone phone = new SmartPhone();
		phone.execute("��");
		phone.execute("����");
		phone.execute("��ȭ");
	}

}
